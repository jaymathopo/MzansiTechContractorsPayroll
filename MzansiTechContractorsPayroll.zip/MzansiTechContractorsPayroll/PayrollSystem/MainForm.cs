namespace MzansiTechContractorsPayroll;

public partial class MainForm : Form
{
    private readonly PayrollCalculator _calculator = new();

    public MainForm()
    {
        InitializeComponent();
    }

    private void btnCalculate_Click(object sender, EventArgs e)
    {
        if (!ValidateInput(out decimal hoursWorked, out int dependents)) return;

        PayrollResult result = _calculator.CalculatePayroll(hoursWorked, dependents);
        txtGrossPay.Text = FormatCurrency(result.GrossPay);
        txtUif.Text = FormatCurrency(result.UifDeduction);
        txtPaye.Text = FormatCurrency(result.PayeDeduction);
        txtMembership.Text = FormatCurrency(result.MembershipFee);
        txtTotalDeductions.Text = FormatCurrency(result.TotalDeductions);
        txtNetPay.Text = FormatCurrency(result.NetPay);
    }

    private bool ValidateInput(out decimal hoursWorked, out int dependents)
    {
        hoursWorked = 0;
        dependents = 0;

        if (string.IsNullOrWhiteSpace(txtContractorName.Text))
        {
            ShowError("Please enter the contractor name.");
            txtContractorName.Focus();
            return false;
        }

        if (!decimal.TryParse(txtHoursWorked.Text, out hoursWorked))
        {
            ShowError("Hours worked must be a numeric value.");
            txtHoursWorked.Focus();
            return false;
        }

        if (hoursWorked < 0)
        {
            ShowError("Hours worked cannot be negative.");
            txtHoursWorked.Focus();
            return false;
        }

        if (!int.TryParse(txtDependents.Text, out dependents))
        {
            ShowError("Number of dependents must be a whole number.");
            txtDependents.Focus();
            return false;
        }

        if (dependents < 0)
        {
            ShowError("Number of dependents cannot be negative.");
            txtDependents.Focus();
            return false;
        }

        if (dependents > 10)
        {
            ShowError("Number of dependents cannot be greater than 10.");
            txtDependents.Focus();
            return false;
        }

        return true;
    }

    private static string FormatCurrency(decimal amount) => $"R {amount:N2}";

    private static void ShowError(string message)
    {
        MessageBox.Show(message, "Input Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
    }

    private void btnReset_Click(object sender, EventArgs e)
    {
        txtContractorName.Clear();
        txtHoursWorked.Clear();
        txtDependents.Clear();
        txtGrossPay.Clear();
        txtUif.Clear();
        txtPaye.Clear();
        txtMembership.Clear();
        txtTotalDeductions.Clear();
        txtNetPay.Clear();
        txtContractorName.Focus();
    }

    private void btnExit_Click(object sender, EventArgs e)
    {
        Close();
    }
}
