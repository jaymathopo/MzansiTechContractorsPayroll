namespace MzansiTechContractorsPayroll;

partial class MainForm
{
    private System.ComponentModel.IContainer components = null!;
    private Label lblTitle = null!;
    private Label lblContractorName = null!;
    private Label lblHoursWorked = null!;
    private Label lblDependents = null!;
    private TextBox txtContractorName = null!;
    private TextBox txtHoursWorked = null!;
    private TextBox txtDependents = null!;
    private Button btnCalculate = null!;
    private Button btnReset = null!;
    private Button btnExit = null!;
    private Label lblGrossPay = null!;
    private Label lblUif = null!;
    private Label lblPaye = null!;
    private Label lblMembership = null!;
    private Label lblTotalDeductions = null!;
    private Label lblNetPay = null!;
    private TextBox txtGrossPay = null!;
    private TextBox txtUif = null!;
    private TextBox txtPaye = null!;
    private TextBox txtMembership = null!;
    private TextBox txtTotalDeductions = null!;
    private TextBox txtNetPay = null!;

    protected override void Dispose(bool disposing)
    {
        if (disposing && components != null)
        {
            components.Dispose();
        }
        base.Dispose(disposing);
    }

    private void InitializeComponent()
    {
        lblTitle = new Label();
        lblContractorName = new Label();
        lblHoursWorked = new Label();
        lblDependents = new Label();
        txtContractorName = new TextBox();
        txtHoursWorked = new TextBox();
        txtDependents = new TextBox();
        btnCalculate = new Button();
        btnReset = new Button();
        btnExit = new Button();
        lblGrossPay = new Label();
        lblUif = new Label();
        lblPaye = new Label();
        lblMembership = new Label();
        lblTotalDeductions = new Label();
        lblNetPay = new Label();
        txtGrossPay = new TextBox();
        txtUif = new TextBox();
        txtPaye = new TextBox();
        txtMembership = new TextBox();
        txtTotalDeductions = new TextBox();
        txtNetPay = new TextBox();
        SuspendLayout();
        // 
        // MainForm
        // 
        AutoScaleDimensions = new SizeF(7F, 15F);
        AutoScaleMode = AutoScaleMode.Font;
        BackColor = Color.Navy;
        ClientSize = new Size(720, 390);
        Controls.Add(lblTitle);
        Controls.Add(lblContractorName);
        Controls.Add(lblHoursWorked);
        Controls.Add(lblDependents);
        Controls.Add(txtContractorName);
        Controls.Add(txtHoursWorked);
        Controls.Add(txtDependents);
        Controls.Add(btnCalculate);
        Controls.Add(btnReset);
        Controls.Add(btnExit);
        Controls.Add(lblGrossPay);
        Controls.Add(lblUif);
        Controls.Add(lblPaye);
        Controls.Add(lblMembership);
        Controls.Add(lblTotalDeductions);
        Controls.Add(lblNetPay);
        Controls.Add(txtGrossPay);
        Controls.Add(txtUif);
        Controls.Add(txtPaye);
        Controls.Add(txtMembership);
        Controls.Add(txtTotalDeductions);
        Controls.Add(txtNetPay);
        FormBorderStyle = FormBorderStyle.FixedSingle;
        MaximizeBox = false;
        Name = "MainForm";
        StartPosition = FormStartPosition.CenterScreen;
        Text = "Mzansi Tech Contractors Payroll System";
        // 
        // labels and text boxes
        // 
        lblTitle.AutoSize = true;
        lblTitle.Font = new Font("Segoe UI", 16F, FontStyle.Bold);
        lblTitle.ForeColor = Color.White;
        lblTitle.Location = new Point(210, 30);
        lblTitle.Text = "Mzansi Tech Contractors";

        lblContractorName.AutoSize = true;
        lblContractorName.ForeColor = Color.White;
        lblContractorName.Location = new Point(95, 105);
        lblContractorName.Text = "Contractor Name";
        txtContractorName.Location = new Point(235, 101);
        txtContractorName.Size = new Size(180, 23);

        lblHoursWorked.AutoSize = true;
        lblHoursWorked.ForeColor = Color.White;
        lblHoursWorked.Location = new Point(95, 145);
        lblHoursWorked.Text = "Hours Worked";
        txtHoursWorked.Location = new Point(235, 141);
        txtHoursWorked.Size = new Size(180, 23);

        lblDependents.AutoSize = true;
        lblDependents.ForeColor = Color.White;
        lblDependents.Location = new Point(95, 185);
        lblDependents.Text = "Number of Dependents";
        txtDependents.Location = new Point(235, 181);
        txtDependents.Size = new Size(180, 23);

        btnCalculate.Location = new Point(120, 235);
        btnCalculate.Size = new Size(135, 32);
        btnCalculate.Text = "Calculate Net Pay";
        btnCalculate.UseVisualStyleBackColor = true;
        btnCalculate.Click += btnCalculate_Click;
        btnReset.Location = new Point(270, 235);
        btnReset.Size = new Size(75, 32);
        btnReset.Text = "Reset";
        btnReset.UseVisualStyleBackColor = true;
        btnReset.Click += btnReset_Click;
        btnExit.Location = new Point(360, 235);
        btnExit.Size = new Size(75, 32);
        btnExit.Text = "Exit";
        btnExit.UseVisualStyleBackColor = true;
        btnExit.Click += btnExit_Click;

        AddOutput(lblGrossPay, txtGrossPay, "Gross Pay", 465, 100);
        AddOutput(lblUif, txtUif, "UIF Deduction", 465, 135);
        AddOutput(lblPaye, txtPaye, "PAYE Deduction", 465, 170);
        AddOutput(lblMembership, txtMembership, "Membership Fee", 465, 205);
        AddOutput(lblTotalDeductions, txtTotalDeductions, "Total Deductions", 465, 240);
        AddOutput(lblNetPay, txtNetPay, "Net Pay", 465, 275);
        ResumeLayout(false);
        PerformLayout();
    }

    private static void AddOutput(Label label, TextBox textBox, string text, int x, int y)
    {
        label.AutoSize = true;
        label.ForeColor = Color.White;
        label.Location = new Point(x, y + 4);
        label.Text = text;
        textBox.Location = new Point(x + 120, y);
        textBox.Size = new Size(105, 23);
        textBox.ReadOnly = true;
        textBox.TabStop = false;
    }
}
