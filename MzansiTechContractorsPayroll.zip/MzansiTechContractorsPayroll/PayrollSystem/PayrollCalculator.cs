namespace MzansiTechContractorsPayroll;

public class PayrollCalculator
{
    public const decimal HourlyRate = 950.00m;
    public const decimal UifRate = 0.01m;
    public const decimal MembershipRate = 0.13m;
    public const decimal DependentReliefRate = 0.0575m;
    public const decimal PayeRate = 0.25m;

    public decimal CalculateGrossPay(decimal hoursWorked) => RoundMoney(hoursWorked * HourlyRate);

    public decimal CalculateUif(decimal grossPay) => RoundMoney(grossPay * UifRate);

    public decimal CalculateMembershipFee(decimal grossPay) => RoundMoney(grossPay * MembershipRate);

    public decimal CalculatePaye(decimal grossPay, int dependents)
    {
        decimal taxableAmount = grossPay - (grossPay * DependentReliefRate * dependents);
        if (taxableAmount < 0) taxableAmount = 0;
        return RoundMoney(taxableAmount * PayeRate);
    }

    public decimal CalculateTotalDeductions(decimal uif, decimal paye, decimal membershipFee) =>
        RoundMoney(uif + paye + membershipFee);

    public decimal CalculateNetPay(decimal grossPay, decimal uif, decimal paye, decimal membershipFee) =>
        RoundMoney(grossPay - uif - paye - membershipFee);

    public PayrollResult CalculatePayroll(decimal hoursWorked, int dependents)
    {
        decimal gross = CalculateGrossPay(hoursWorked);
        decimal uif = CalculateUif(gross);
        decimal paye = CalculatePaye(gross, dependents);
        decimal membership = CalculateMembershipFee(gross);
        decimal totalDeductions = CalculateTotalDeductions(uif, paye, membership);
        decimal net = CalculateNetPay(gross, uif, paye, membership);

        return new PayrollResult(gross, uif, paye, membership, totalDeductions, net);
    }

    private static decimal RoundMoney(decimal amount) => Math.Round(amount, 2, MidpointRounding.AwayFromZero);
}

public record PayrollResult(
    decimal GrossPay,
    decimal UifDeduction,
    decimal PayeDeduction,
    decimal MembershipFee,
    decimal TotalDeductions,
    decimal NetPay);
