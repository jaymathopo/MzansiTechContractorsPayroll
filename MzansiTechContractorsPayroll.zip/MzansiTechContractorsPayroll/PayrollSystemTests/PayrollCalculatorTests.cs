using Microsoft.VisualStudio.TestTools.UnitTesting;
using MzansiTechContractorsPayroll;

namespace MzansiTechContractorsPayroll.Tests;

[TestClass]
public class PayrollCalculatorTests
{
    private PayrollCalculator _calculator = null!;
    public TestContext TestContext { get; set; } = null!;

    [TestInitialize]
    public void Setup()
    {
        _calculator = new PayrollCalculator();
    }

    [TestMethod]
    [TestCategory("Unit Testing")]
    public void CalculateGrossPay_WhenHoursAre40_Returns38000()
    {
        decimal actual = _calculator.CalculateGrossPay(40m);
        TestContext.WriteLine($"Gross Pay expected R 38,000.00 and actual R {actual:N2}");
        Assert.AreEqual(38000.00m, actual);
    }

    [TestMethod]
    [TestCategory("Unit Testing")]
    public void CalculateUif_WhenGrossPayIs38000_Returns380()
    {
        decimal actual = _calculator.CalculateUif(38000m);
        TestContext.WriteLine($"UIF expected R 380.00 and actual R {actual:N2}");
        Assert.AreEqual(380.00m, actual);
    }

    [TestMethod]
    [TestCategory("Unit Testing")]
    public void CalculateMembershipFee_WhenGrossPayIs38000_Returns4940()
    {
        decimal actual = _calculator.CalculateMembershipFee(38000m);
        TestContext.WriteLine($"Membership expected R 4,940.00 and actual R {actual:N2}");
        Assert.AreEqual(4940.00m, actual);
    }

    [TestMethod]
    [TestCategory("Unit Testing")]
    public void CalculatePaye_WhenGrossPay38000AndTwoDependents_Returns8407Point50()
    {
        decimal actual = _calculator.CalculatePaye(38000m, 2);
        TestContext.WriteLine($"PAYE expected R 8,407.50 and actual R {actual:N2}");
        Assert.AreEqual(8407.50m, actual);
    }

    [TestMethod]
    [TestCategory("Unit Testing")]
    public void CalculateNetPay_WhenUsingValidDeductions_Returns24272Point50()
    {
        decimal actual = _calculator.CalculateNetPay(38000m, 380m, 8407.50m, 4940m);
        TestContext.WriteLine($"Net Pay expected R 24,272.50 and actual R {actual:N2}");
        Assert.AreEqual(24272.50m, actual);
    }

    [TestMethod]
    [TestCategory("Integration Testing")]
    public void CalculatePayroll_WhenHours40AndTwoDependents_ReturnsAllExpectedOutputs()
    {
        PayrollResult result = _calculator.CalculatePayroll(40m, 2);
        TestContext.WriteLine($"Gross Pay: R {result.GrossPay:N2}");
        TestContext.WriteLine($"UIF: R {result.UifDeduction:N2}");
        TestContext.WriteLine($"PAYE: R {result.PayeDeduction:N2}");
        TestContext.WriteLine($"Membership: R {result.MembershipFee:N2}");
        TestContext.WriteLine($"Total Deductions: R {result.TotalDeductions:N2}");
        TestContext.WriteLine($"Net Pay: R {result.NetPay:N2}");

        Assert.AreEqual(38000.00m, result.GrossPay);
        Assert.AreEqual(380.00m, result.UifDeduction);
        Assert.AreEqual(8407.50m, result.PayeDeduction);
        Assert.AreEqual(4940.00m, result.MembershipFee);
        Assert.AreEqual(13727.50m, result.TotalDeductions);
        Assert.AreEqual(24272.50m, result.NetPay);
    }
}
